#include<stdio.h>
#include<fcntl.h>

int main() {
	int file1 = creat("file1.txt",0644);
	int file2 = creat("file2.txt",0644);
	int file3 = creat("file3.txt",0644);
	int file4 = creat("file4.txt",0644);
	int file5 = creat("file5.txt",0644);
	while(1);
}

